WIKI_PAGES = YAML.load_file(Rails.root.join("config/wiki_pages.yml"))
