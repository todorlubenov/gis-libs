Rails.application.config.exceptions_app = Rails.application.routes
